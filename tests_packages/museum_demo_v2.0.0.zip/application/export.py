"""Экспорт демонстрационного списка в CSV."""

import csv
import io


def export_inventory_csv(items):
    output = io.StringIO(newline="")
    fieldnames = ["inventory_number", "title", "category", "preservation_status"]
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(items)
    return output.getvalue()
