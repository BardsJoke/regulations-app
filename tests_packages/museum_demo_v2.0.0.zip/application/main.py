"""Лабораторное приложение: реестр музейной коллекции, версия 2.0.0."""

import json
from application.catalog import search_items
from application.export import export_inventory_csv

APP_NAME = "Museum Collection Registry Demo"
APP_VERSION = "2.0.0"
FEATURES = [
    "просмотр музейной коллекции",
    "просмотр карточек предметов",
    "поиск по названию и инвентарному номеру",
    "экспорт списка предметов в CSV",
    "просмотр статуса сохранности",
]

SAMPLE_ITEMS = [
    {"inventory_number": "LAB-0001", "title": "Керамический сосуд", "category": "археология", "preservation_status": "стабильное"},
    {"inventory_number": "LAB-0002", "title": "Графический лист", "category": "графика", "preservation_status": "требуется наблюдение"},
    {"inventory_number": "LAB-0003", "title": "Историческая фотография", "category": "фотография", "preservation_status": "стабильное"},
    {"inventory_number": "LAB-0004", "title": "Фрагмент ткани", "category": "текстиль", "preservation_status": "требуется консервация"},
]

def get_status():
    return {
        "application": APP_NAME,
        "version": APP_VERSION,
        "status": "ok",
        "features": FEATURES,
        "items_count": len(SAMPLE_ITEMS),
    }

if __name__ == "__main__":
    print(json.dumps(get_status(), ensure_ascii=False, indent=2))
    print("\nРезультат тестового поиска:")
    print(json.dumps(search_items(SAMPLE_ITEMS, "LAB-0002"), ensure_ascii=False, indent=2))
    print("\nТестовый CSV:")
    print(export_inventory_csv(SAMPLE_ITEMS))
