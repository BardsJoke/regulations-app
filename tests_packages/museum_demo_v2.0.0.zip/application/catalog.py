"""Поиск по демонстрационному каталогу."""

def search_items(items, query):
    query = str(query).casefold().strip()
    if not query:
        return list(items)
    return [
        item for item in items
        if query in item.get("title", "").casefold()
        or query in item.get("inventory_number", "").casefold()
    ]
